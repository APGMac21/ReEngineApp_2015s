A08_CameraSingleton by: Gregory McClellan and Gregory Bednarowicz
Use WASD to move
Use up and down arrows to pitch
Use left and right arrows to yaw
Use R and F to roll
T toggles the ortho view