#include "AppClass.h"
void AppClass::InitWindow(String a_sWindowName)
{
	super::InitWindow("A12_Octree"); // Window Name

	// Set the clear color based on Microsoft's CornflowerBlue (default in XNA)
	//if this line is in Init Application it will depend on the .cfg file, if it
	//is on the InitVariables it will always force it regardless of the .cfg
	m_v4ClearColor = vector4(0.4f, 0.6f, 0.9f, 0.0f);
	//m_pSystem->SetWindowResolution(RESOLUTIONS::HD_1280X720);
	//m_pSystem->SetWindowFullscreen(); //Sets the window to be fullscreen
	//m_pSystem->SetWindowBorderless(true); //Sets the window to not have borders
}

void AppClass::InitVariables(void)
{
	useSO = true;
	//Reset the selection to -1, -1
	m_selection = std::pair<int, int>(-1, -1);
	//Set the camera position
	m_pCameraMngr->SetPositionTargetAndView(
		vector3(0.0f, 0.0f, 35.0f),//Camera position
		vector3(0.0f, 0.0f, 0.0f),//What Im looking at
		REAXISY);//What is up
	m_pBOMngr = MyBOManager::GetInstance();
	//Load a model onto the Mesh manager
	for (uint i = 0; i < 300; i++)
	{
		String name = "Creeper" + std::to_string(i);
		matrix4 objectMatrix = IDENTITY_M4 * glm::translate(glm::sphericalRand(10.0f));
		//m_pMeshMngr->AddCubeToRenderList(objectMatrix, REBLUE, SOLID);
		m_pMeshMngr->LoadModel("Minecraft\\Creeper.obj", name, false, glm::translate(glm::sphericalRand(10.0f)));
		m_pBOMngr->AddObject(name);
	}

	m_pOctreeHead = new MyOctant();
	m_pOctreeHead->Subdivide(m_pBOMngr->GetBOVector());
}

void AppClass::Update(void)
{
	//Update the system's time
	m_pSystem->UpdateTime();

	//Update the mesh manager's time without updating for collision detection
	m_pMeshMngr->Update();

	//First person camera movement
	if (m_bFPC == true)
		CameraRotation();

	//Call the arcball method
	ArcBall();

	//m_pBOMngr->Update();
	
	//Set the model matrix for the first model to be the arcball
	m_pMeshMngr->SetModelMatrix(ToMatrix4(m_qArcBall), 0);
	
	//Adds all loaded instance to the render list
	m_pMeshMngr->AddInstanceToRenderList("ALL");

	//Check Collisions
	if (useSO) 
	{
		m_pOctreeHead->CheckCollisions();
	}
	else
	{
		m_pBOMngr->Update();
	}

	if (displayOctree)
	{
		m_pOctreeHead->Draw();
	}

	//Indicate the FPS
	int nFPS = m_pSystem->GetFPS();
	//print info into the console
	//printf("FPS: %d            \r", nFPS);//print the Frames per Second
	//Print info on the screen
	m_pMeshMngr->PrintLine(m_pSystem->GetAppName(), REYELLOW);
	
	m_pMeshMngr->Print("FPS:");
	m_pMeshMngr->PrintLine(std::to_string(nFPS), RERED);
	m_pMeshMngr->Print("<K> Check Collisions: ");
	if (useSO)
	{
		m_pMeshMngr->PrintLine("Spatial Optimization", REGREEN);
	}
	else
	{
		m_pMeshMngr->PrintLine("Brute Force", RERED);
	}
	m_pMeshMngr->Print("<H> Display Octree: ");
	if (displayOctree)
	{
		m_pMeshMngr->PrintLine("ON", REGREEN);
	}
	else
	{
		m_pMeshMngr->PrintLine("OFF", RERED);
	}
	m_pMeshMngr->Print("<J> Display Collisions For SO: ");
	if (m_pOctreeHead->GetDisplaySphere())
	{
		m_pMeshMngr->PrintLine("ON", REGREEN);
	}
	else
	{
		m_pMeshMngr->PrintLine("OFF", RERED);
	}
	m_pMeshMngr->Print("<G> Display Collisions For Brute Force: ");
	if (m_pBOMngr->GetDisplaySphere())
	{
		m_pMeshMngr->PrintLine("ON", REGREEN);
	}
	else
	{
		m_pMeshMngr->PrintLine("OFF", RERED);
	}
}

void AppClass::Display(void)
{
	//clear the screen
	ClearScreen();
	//Render the grid based on the camera's mode:
	m_pMeshMngr->AddGridToRenderListBasedOnCamera(m_pCameraMngr->GetCameraMode());
	m_pMeshMngr->Render(); //renders the render list
	m_pMeshMngr->ResetRenderList(); //Reset the Render list after render
	m_pGLSystem->GLSwapBuffers(); //Swaps the OpenGL buffers
}

void AppClass::Release(void)
{
	m_pOctreeHead->DestroyOctant();
	SafeDelete(m_pOctreeHead);
	super::Release(); //release the memory of the inherited fields
}